package java_jenkis.soum.model;

public enum NiveauEnum {
	B1,
	B2,
	B3,
	I4,
	I5
}
