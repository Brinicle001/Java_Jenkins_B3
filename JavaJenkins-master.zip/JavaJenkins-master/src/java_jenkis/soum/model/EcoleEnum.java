package java_jenkis.soum.model;

public enum EcoleEnum {
	EPSI,
	IFAG,
	SUPDECOM,
	IEFT
}
